INSERT INTO users VALUES (1, 'ivan@example.com', '@telegram_user');
INSERT INTO users VALUES (2, 'test@company.ru', '0x742d35Cc6634C0532925a3b844Bc454e4438f44e');
